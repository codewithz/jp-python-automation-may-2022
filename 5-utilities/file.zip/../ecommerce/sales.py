def calculate_tax():
    print("Calculate Tax in Sales of Ecommerce")

def calculate_shipping():
    print("Calculate Shipping in Sales of Ecommerce")
    